<ul class="navigation">
	<li class="navigation__items">
		<a href="3" class="navigation__link">
			Услуги и цены
		</a>
	</li>
	<li class="navigation__items">
		<a href="3" class="navigation__link">
			Портфолио
		</a>
	</li>
	<li class="navigation__items">
		<a href="3" class="navigation__link">
			Преимущества
		</a>
	</li>
	<li class="navigation__items">
		<a href="3" class="navigation__link">
			Отзывы
		</a>
	</li>
	<li class="navigation__items">
		<a href="3" class="navigation__link">
			Контакты
		</a>
	</li>
</ul>
